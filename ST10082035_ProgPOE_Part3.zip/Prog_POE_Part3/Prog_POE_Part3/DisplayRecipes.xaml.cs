﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prog_POE_Part3
{
    /// <summary>
    /// Interaction logic for DisplayRecipes.xaml
    /// </summary>
    public partial class DisplayRecipes : Window
    {
        private List<RecipeEntry> recipeEntries;

        public DisplayRecipes(List<RecipeEntry> recipes)
        {
            InitializeComponent();
            recipeEntries = recipes;

            // Populate the ListBox with the recipe names
            foreach (RecipeEntry recipeEntry in recipeEntries)
            {
                recipesListBox.Items.Add(recipeEntry.RecipeName);
            }
        }
    }
}
