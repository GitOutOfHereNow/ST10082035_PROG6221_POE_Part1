﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prog_POE_Part3
{
    /// <summary>
    /// ST10082035
    /// PROG6221
    /// POE PART 3
    /// </summary>
    public partial class CreateRecipe : Window
    {
        private List<RecipeEntry> recipeEntries; // List to store the recipe entries

        public CreateRecipe()
        {
            InitializeComponent();
            // Handle the Loaded event of the window
            Loaded += CreateRecipe_Loaded;
         //   numberOfIngredientsComboBox.SelectionChanged += numberOfIngredientsComboBox_SelectionChanged;

            recipeEntries = new List<RecipeEntry>(); // Initialize the list
        }

        private void CreateRecipe_Loaded(object sender, RoutedEventArgs e)
        {
            // Get a reference to the ComboBox
            ComboBox numberOfIngredientsComboBox = FindName("numberOfIngredientsComboBox") as ComboBox;

            // Populate the ComboBox with numbers from 1 to 50
            for (int i = 1; i <= 50; i++)
            {
                numberOfIngredientsComboBox.Items.Add(i);
            }
        }

        private void numberOfIngredientsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Clear existing textboxes
            ingredientStackPanel.Children.Clear();

            // Get the selected number of ingredients
            int selectedNumber = (int)numberOfIngredientsComboBox.SelectedItem;

            // Generate textblocks and textboxes based on the selected number
            for (int i = 1; i <= selectedNumber; i++)
            {
                TextBlock textBlock = new TextBlock();
                textBlock.Text = "Enter Name of ingredient:";
                textBlock.Margin = new Thickness(0, 5, 0, 0);
                textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                textBlock.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(textBlock);

                TextBox nameIng = new TextBox();
                nameIng.Width = 300;
                nameIng.Margin = new Thickness(0, 5, 0, 0);
                nameIng.HorizontalAlignment = HorizontalAlignment.Right;
                nameIng.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(nameIng);

                TextBlock quantity = new TextBlock();
                quantity.Text = "Enter quantity of ingredient:";
                quantity.Margin = new Thickness(0, 5, 0, 0);
                quantity.HorizontalAlignment = HorizontalAlignment.Left;
                quantity.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(quantity);

                TextBox QuantIng = new TextBox();
                QuantIng.Width = 300;
                QuantIng.Margin = new Thickness(0, 5, 0, 0);
                QuantIng.HorizontalAlignment = HorizontalAlignment.Right;
                QuantIng.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(QuantIng);

                TextBlock unitMeasure = new TextBlock();
                unitMeasure.Text = "Enter unit of measurement:";
                unitMeasure.Margin = new Thickness(0, 5, 0, 0);
                unitMeasure.HorizontalAlignment = HorizontalAlignment.Left;
                unitMeasure.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(unitMeasure);

                TextBox MeasIng = new TextBox();
                MeasIng.Width = 300;
                MeasIng.Margin = new Thickness(0, 5, 0, 0);
                MeasIng.HorizontalAlignment = HorizontalAlignment.Right;
                MeasIng.VerticalAlignment = VerticalAlignment.Top;
                ingredientStackPanel.Children.Add(MeasIng);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = recipeNameTextBox.Text;

            // Creates a new RecipeEntry instance
            RecipeEntry recipeEntry = new RecipeEntry(recipeName);

            // Iterate over the textboxes and retrieve the user entries
            foreach (UIElement element in ingredientStackPanel.Children)
            {
                if (element is TextBox textBox)
                {
                    // Adds the user entry to the RecipeEntry instance
                    recipeEntry.Ingredients.Add(textBox.Text);
                }
            }

            // Adds the RecipeEntry instance to the list
            recipeEntries.Add(recipeEntry);

            // Clears the textboxes and recipe name
            recipeNameTextBox.Clear();
            ingredientStackPanel.Children.Clear();
            numberOfIngredientsComboBox.SelectedIndex = -1;
        }
    }

    // A helper class to store recipe entries
    public class RecipeEntry
    {
        public string RecipeName { get; set; }
        public List<string> Ingredients { get; set; }

        public RecipeEntry(string recipeName)
        {
            RecipeName = recipeName;
            Ingredients = new List<string>();
        }
    }
}